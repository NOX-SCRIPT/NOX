# NOX-SCRIPT/NOX

## File layout

```text
NOX/
├── noxloader.lua
└── GAMES/
    ├── sae.lua
    └── bloxfruits.lua
```

## Setup
1. Upload `noxloader.lua` to the repository root.
2. Upload `sae.lua` and `bloxfruits.lua` into `GAMES/`.
3. Confirm each configured ID matches the intended Roblox `PlaceId`.
4. Replace the game module templates with code for an experience you own.

## Important
`noxloader.lua` currently resolves a URL; it does not download or execute it.
For Roblox experiences you own, use `ModuleScript` and `require()` in Roblox Studio.
