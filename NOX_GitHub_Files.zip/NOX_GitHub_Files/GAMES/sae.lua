-- NOX game module template: sae.lua
-- Replace this template with code for an experience you own.
-- For Roblox Studio, put this in a ModuleScript and require it from your game.

local SAE = {}

function SAE.Init()
    -- Add your authorized game functionality here.
end

return SAE
